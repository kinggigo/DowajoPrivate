//import 'package:flutter_riverpod/flutter_riverpod.dart';
/*import 'package:dowajo/components/models/injectModel.dart';

final InjectListProvider =
    StateNotifierProvider<InjectListNotifier, List<InjectModels>>(
        (ref) => InjectListNotifier());

class InjectListNotifier extends StateNotifier<List<InjectModels>> {
  InjectListNotifier() : super([]);

  void addInject(InjectModels inject) {
    state = [...state, inject];
  }
}
*/